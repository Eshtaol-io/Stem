Enumerations
============

.. automodule:: stem.util.enum


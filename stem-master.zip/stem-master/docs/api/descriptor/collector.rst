CollecTor
=========

.. automodule:: stem.descriptor.collector


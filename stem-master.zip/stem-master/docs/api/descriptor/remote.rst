Descriptor Remote
=================

.. automodule:: stem.descriptor.remote


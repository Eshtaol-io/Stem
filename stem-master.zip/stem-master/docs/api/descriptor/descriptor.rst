Descriptor
==========

.. automodule:: stem.descriptor


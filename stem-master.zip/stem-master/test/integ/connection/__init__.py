"""
Integration tests for stem.connection.
"""

__all__ = ['authenticate', 'connect']

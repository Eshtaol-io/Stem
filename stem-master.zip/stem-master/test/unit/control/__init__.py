"""
Unit tests for stem.control.
"""

__all__ = ['controller']
